import os
from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, url_for
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
import numpy as np
import datetime
import matplotlib.pyplot as plt
import uuid

from helpers import apology, login_required
from integrals import integral_calculator, plot_integral, parse_function, calculation_complexity

# Configure application
app = Flask(__name__)

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///defenite_integral_calculator.db")

@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

@app.route("/")
@login_required
def index():
    '''History of calculated integrals'''
    user_id = session["user_id"]
    #Orders the results and content of calculated integrals so that most recently calculated is first to appear
    calculations = db.execute("SELECT * FROM calculations WHERE user_id = :user_id ORDER BY timestamp DESC", user_id=user_id)
    return render_template("index.html", calculations=calculations)

@app.route("/calculate", methods=["GET", "POST"])
@login_required
def calculate():
    '''Calculates integral, provides graph and complexity'''
    if request.method == "POST":
        user_id = session["user_id"]
        # Get the inputted function, segment number and upper and lower bounds
        upper = request.form.get("upper")
        lower = request.form.get("lower")
        n = request.form.get("n")
        f = request.form.get("function")

        # Confirms that inputs are of correct type and exist
        try:
            upper = float(upper)
            lower = float(lower)
            n = int(n)
        except ValueError:
            return apology("Invalid numerical inputs", 400)

        # Formats the inputted integral in a way so that the defenite integral can be calculated
        function = parse_function(f)
        # In the event a function is not inputted, return error
        if function is None:
            return apology("Must input a function", 400)

        # Calculate the integral
        try:
            # Gets the defenite integral result
            result = integral_calculator(function, lower, upper, n)
            # Gets the filename of graph created and stored in static folder for calcualted integral
            plot_filename = plot_integral(function, lower, upper, n)
            # Gets complexity rating and explanation
            complexity = calculation_complexity(f, lower, upper)
            # Get a timestamp of when calculation occurs so that we can store and display are calculations in a coherent manenr
            timestamp = datetime.datetime.now()

            # Save calculation to SQLITE3 database in table named, calculations
            result_id = db.execute("INSERT INTO calculations (user_id, inputs, upper, lower, n, result, plot_filename, complexity, timestamp) VALUES (:user_id, :inputs, :upper, :lower, :n, :result, :plot_filename, :complexity, :timestamp)",
                user_id=user_id, inputs=f, upper=upper, lower=lower, n=n, result=result, plot_filename=plot_filename, complexity=complexity, timestamp=timestamp)

            # Displays result page which contsains integral result and graph
            return redirect(url_for("result", calc_id=result_id))

        # In the event an error is thrown in trying to calcualte the integral return an error
        except Exception as e:
            return apology(f"Error calculating integral: {e}", 500)

    # In the event user ins't submitting anything to page and is just trying to access it
    return render_template("calculate.html")


@app.route("/result/<int:calc_id>")
@login_required
def result(calc_id):
    '''Displays result and graph of calculated defenite integral'''
    user_id = session["user_id"]
    # Calc id is passed in and is what allows us to get the result of the correct defenite integral for user
    # In other words it gives us access to the specefic calculation we are looking for from user
    result_row = db.execute("SELECT * FROM calculations WHERE id = :calc_id AND user_id = :user_id", calc_id=calc_id, user_id=user_id)

    # In the event no calculation is found
    if not result_row:
        return apology("No results found", 400)

    # Get function/integral result, graph/filename and the inputted function/integral
    result_row = result_row[0]
    result = result_row["result"]
    plot_filename = result_row["plot_filename"]

    # Returns page that displays result and graph
    return render_template("result.html", result=result, plot_filename=plot_filename)

# This fnuctions is mostly from Finance PSET.  Few minor adjustments to account for errors
@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""
    session.clear()
    if request.method == "POST":
        # Gets inputted username and password
        username = request.form.get("username")
        password = request.form.get("password")

        # In the event user does not input username or password
        if not username or not password:
            return apology("Username and password are required", 400)

        # Query user from database in order to check/validate password and username
        user = db.execute("SELECT * FROM users WHERE username = :username", username=username)

        # in the event user does not exist or password is not found
        if not user or not check_password_hash(user["hash"], password):
            return apology("Invalid username and/or password", 403)

        session["user_id"] = user["id"]
        return redirect("/")

    # In the event user has not submitted login info and is just accessing the page
    return render_template("login.html")

# From Finance PSET
@app.route("/logout")
def logout():
    """Log user out"""
    session.clear()
    return redirect("/")

@app.route("/about")
@login_required
def about():
    '''Renders page that displays information on how calculator works/about defenite integrals'''
    return render_template("about.html")

# Modified from Finance PSET
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        # Gets username, password, and second input of password (confirmation)
        username = request.form.get("username")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")

        # Check if all fields are provided
        if not username or not password or not confirmation:
            return apology("All fields are required", 400)

        # Check if password and confirmation match
        if password != confirmation:
            return apology("Passwords do not match", 400)

        # Validate username length
        if len(username) < 5:
            return apology("Username must be at least 5 characters long", 400)

        # Validate password complexity
        if len(password) < 8 or not any(char.isdigit() for char in password) or not any(char.isalpha() for char in password):
            return apology("Password must be at least 8 characters long and contain both letters and numbers", 400)

        # Check if username already exists
        existing_user = db.execute("SELECT * FROM users WHERE username = :username", username=username)
        if existing_user:
            return apology("Username already exists", 400)

        # Insert new user into database
        hash = generate_password_hash(password)
        db.execute("INSERT INTO users (username, hash) VALUES (:username, :hash)", username=username, hash=hash)

        # Retrieve new user id
        new_user = db.execute("SELECT * FROM users WHERE username = :username", username=username)
        session["user_id"] = new_user[0]["id"]

        # Redirect to calculate page
        return redirect(url_for("calculate"))

    # Render registration page if method is GET
    return render_template("register.html")


