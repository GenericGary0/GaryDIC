import csv
import datetime
import pytz
import requests
import urllib
import uuid
import math

from flask import redirect, render_template, request, session
from functools import wraps

# From Finance PSET.  HTML/API is modified however
def apology(message, code=400):
    """Render message as an apology to user."""

    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [
            ("-", "--"),
            (" ", "-"),
            ("_", "__"),
            ("?", "~q"),
            ("%", "~p"),
            ("#", "~h"),
            ("/", "~s"),
            ('"', "''"),
        ]:
            s = s.replace(old, new)
        return s

    return render_template("apology.html", top=code, bottom=escape(message)), code

# From Finance PSET
def login_required(f):
    """
    Decorate routes to require login.

    https://flask.palletsprojects.com/en/latest/patterns/viewdecorators/
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)

    return decorated_function

'''
def safe_eval(expression):
    """Evaluate a mathematical expression safely."""
    expression = expression.replace('^', '**')  # Correct replacement for exponentiation
    allowed_names = {
        'sqrt': math.sqrt,
        'log': math.log,
        'exp': math.exp,
        'pow': pow,
        'pi': math.pi,
        'e': math.e,
        'abs': abs,  # Allow absolute value function
        'sin': math.sin,
        'cos': math.cos,
        'tan': math.tan,
        'atan': math.atan,
        'asin': math.asin,
        'acos': math.acos,
    }

    def safe_eval_internal(expr, env):
        try:
            return eval(expr, {"__builtins__": None}, env)
        except Exception as e:
            raise ValueError(f"Error evaluating expression: {e}")

    return safe_eval_internal(expression, allowed_names)'''



