import matplotlib
matplotlib.use('Agg')  # Use 'Agg' backend to avoid GUI-related issues

import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
import uuid
import os
from groq import Groq

from helpers import apology

def integral_calculator(f, a, b, n):
    '''Calculates result of definite integral using the trapezoidal rule'''
    try:
        # Calculates the width of each trapezoid
        h = (b - a) / n

        # Creates array of segments/end points to work with
        x = np.linspace(a, b, n + 1)  # n + 1 points, which results in n segments

        # Evaluate function at each point and convert to list
        y = f(x).tolist()

        # Formula for calculating integral using the trapezoidal rule
        integral = (h / 2) * (y[0] + 2 * sum(y[1:-1]) + y[-1])
        return integral

    except Exception as e:
        return apology(f"Error in integral calculation: {e}", 500)

def plot_integral(f, a, b, n):
    '''Creates a PNG file of the integral plot and returns the filename'''
    try:
        x = np.linspace(a, b, 400)  # Generate 400 points for smooth plot
        y = f(x)  # Evaluate function at these points
        plt.plot(x, y, label='f(x)')  # Plot the function
        plt.fill_between(x, 0, y, alpha=0.2)  # Fill area under the curve
        plt.xlabel('x')
        plt.ylabel('f(x)')
        plt.title('Definite Integral of f(x) from {} to {}'.format(a, b))
        plt.grid(True)

        # Ensure the plots directory exists
        static_dir = 'plots'
        if not os.path.exists(static_dir):
            os.makedirs(static_dir)

        # Generate a unique filename to avoid duplicates
        file_name = 'graph_{}.png'.format(uuid.uuid4())
        file_path = os.path.join(static_dir, file_name)

        plt.savefig(file_path)  # Save the plot as a PNG file
        plt.close()  # Close the plot to free up memory
        return file_name

    except Exception as e:
        return apology(f"Error in plotting integral: {e}", 500)

def parse_function(user_input):
    '''Converts function string into a format for calculations using sympy'''
    try:
        # Replace common function notations
        user_input = user_input.replace('^', '**')  # Replace '^' with '**' for exponentiation

        # Define the symbol/variable used in the function
        x = sp.symbols('x')

        # Parse the function with sympy
        f = sp.sympify(user_input, locals={'sqrt': sp.sqrt, 'sin': sp.sin, 'cos': sp.cos, 'log': sp.log})

        # Create a lambda function for numerical evaluation
        parsed_function = sp.lambdify(x, f, 'numpy')
        return parsed_function

    except Exception as e:
        return apology(f"Error in parsing function: {e}", 500)

def calculation_complexity(f, a, b):
    '''Returns complexity rating and explanation using AI API'''
    try:
        # API key for Groq service
        api_key = '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'

        # Initialize the Groq client
        client = Groq(api_key=api_key)

        # Create a chat completion request
        chat_completion = client.chat.completions.create(
            messages=[
                {
                    "role": "user",
                    # Input/question for the AI API
                    "content": f"In a couple sentences (without saying 'I'), rate on a scale of 1-10 and explain the calculation complexity for the provided definite integral. Function- {f}, lower bound- {a}, upper bound {b}:",
                }
            ],
            model="llama3-8b-8192"  # Specify the model to use
        )

        # Access the AI-generated response
        choices = chat_completion.choices
        if choices:
            return choices[0].message.content

    except Exception as e:
        return apology(f"An error occurred trying to generate a rating: {e}", 500)
